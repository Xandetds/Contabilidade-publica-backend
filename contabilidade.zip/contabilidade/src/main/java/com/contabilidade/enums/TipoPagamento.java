package com.contabilidade.enums;

public enum TipoPagamento {
    NORMAL,
    RESTOS_A_PAGAR
}
