package com.contabilidade.enums;

public enum TipoUnidadeGestora {
    PREFEITURA,
    CAMARA,
    FUNDACAO,
    AUTARQUIA
}
