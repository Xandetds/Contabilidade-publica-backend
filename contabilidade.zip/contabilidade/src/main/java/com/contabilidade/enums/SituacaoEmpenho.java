package com.contabilidade.enums;

public enum SituacaoEmpenho {
    EM_ABERTO,
    LIQUIDADO,
    CANCELADO
}
