package com.contabilidade.enums;

public enum TipoCredor {
    PESSOA_FISICA,
    PESSOA_JURIDICA
}
