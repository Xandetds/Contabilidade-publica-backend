package com.contabilidade.enums;

public enum PerfilUsuario {
    CONTADOR,
    CONTROLADOR,
    VISUALIZACAO
}
